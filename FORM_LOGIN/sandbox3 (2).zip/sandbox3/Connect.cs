﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sandbox3
{
    internal class Connect
    {
        string QueryCommand = "SERVER = localhost; database = pt_sinar; UID = root; pwd = ''";
        public MySqlConnection konek;
        public void Conn()
        {
            konek = new MySqlConnection(QueryCommand);
            konek.Open();
        }
        public void DissConn()
        {
            konek = new MySqlConnection(QueryCommand);
            konek.Close();
        }
    }
}
