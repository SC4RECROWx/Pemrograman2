﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace sandbox3
{
    public partial class Delete : Form
    {
        public Delete()
        {
            InitializeComponent();
        }
        public MySqlConnection conn = new MySqlConnection();
        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            string constring = "SERVER = localhost; database = pt_sinar; UID = root; pwd = ''";
            string QueryCommand = "delete from data_barang where KODE_BARANG = '" + this.Kdbox.Text + "' ;";
            MySqlConnection con_DataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(QueryCommand, con_DataBase);
            MySqlDataReader MyReader;
            /*
            con_DataBase.Open();
            MyReader= cmdDataBase.ExecuteReader();
            MessageBox.Show("Data Telah Di Hapus");
            while (MyReader.Read())
            {

            }
            */
            try
            {
                con_DataBase.Open();
                MyReader = cmdDataBase.ExecuteReader();
                MessageBox.Show("Data Telah Di Hapus");
                while (MyReader.Read())
                {

                }
            }
            
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            /*
            string db = "SERVER = localhost; database = pt_sinar; UID = root; pwd = ''";
            conn = new MySqlConnection(db);
            conn.Open();
            try
            {
                string kode = Kdbox.Text;
                string comand = $"delete from data_barang where KODE_BARANG = '{kode}'";
                MySqlCommand cmd = new MySqlCommand(comand, conn);
                cmd.ExecuteReader();
                MessageBox.Show("Data Telah Di Hapus");
            }
            catch
            {
                MessageBox.Show("Data Tidak Ditemukan");
            }
            conn.Close();
            */
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
