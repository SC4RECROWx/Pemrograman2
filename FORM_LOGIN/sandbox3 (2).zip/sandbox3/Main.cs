﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace sandbox3
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        
        private void Loggoff_Click(object sender, EventArgs e)
        {
            Login ObjLogin = new Login();
            this.Close();
            ObjLogin.Show();
        }

        MySqlConnection Connect = new MySqlConnection("datasource = localhost; database = pt_sinar; UID = root;");

        public DataTable datasequel()
        {
            string QueryCommand = "select * from data_barang";
            DataTable Data_Barang = new DataTable();
            MySqlDataAdapter DataAdp = new MySqlDataAdapter(QueryCommand, Connect);
            DataAdp.Fill(Data_Barang);
            dataGridView1.DataSource = Data_Barang;
            Connect.Close();
            return (Data_Barang);
        }

        private void ShowBtn_Click(object sender, EventArgs e)
        {
            datasequel();
        }

        private void InputBtn_Click(object sender, EventArgs e)
        {
            Input Obj_Input = new Input();
            Obj_Input.Show();
        }

        private void DelBtn_Click_1(object sender, EventArgs e)
        {
            Delete Obj_del = new Delete();
            Obj_del.Show();
        }
    }
}
