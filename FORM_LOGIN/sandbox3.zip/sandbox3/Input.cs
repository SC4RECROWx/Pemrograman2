﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace sandbox3
{
    public partial class Input : Form
    {
        public Input()
        {
            InitializeComponent();
        }
        private void InputBtn_Click(object sender, EventArgs e)
        {
            string ItemCode = KodeBarang.Text;
            string ItemName = NamaBarang.Text;
            int ItemStock = Convert.ToInt32(StockBarang.Text);
            DateTime Date = Convert.ToDateTime(Tanggal.Text);
            string seqieul = $"insert into data_barang(KODE_BARANG,NAMA_BARANG,STOCK_BARANG,TANGGAL) values('{ItemCode}','{ItemCode}','{ItemStock}','{Date}'";
            
            DataTable DataBarang = new DataTable();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
