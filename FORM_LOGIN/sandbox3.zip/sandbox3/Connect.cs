﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sandbox3
{
    internal class Connect
    {
        public MySqlConnection conn = new MySqlConnection("SERVER = localhost; database = pt_sinar; UID = root;");
        public void Conn()
        {
            conn.Open();
        }
        public void DissConn()
        {
            conn.Close();
        }
    }
}
